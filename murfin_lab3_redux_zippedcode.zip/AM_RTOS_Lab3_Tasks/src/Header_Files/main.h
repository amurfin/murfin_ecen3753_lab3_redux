//***********************************************************************************
// Include files
//***********************************************************************************

#include <stdint.h>
#include <stdbool.h>

//***********************************************************************************
// defined files
//***********************************************************************************
//#define LAB2_USE_INTERRUPT
#define	INFINITE_LOOP		true
#define OS_SEM_INIT_CLEAR	0
#define	OS_TIMEOUT_NONE		0

// Micrium OS Defines
#define  EX_MAIN_START_TASK_PRIO		21u
#define  EX_MAIN_START_TASK_STK_SIZE    512u
#define  EX_BUTTON_INPUT_TASK_PRIO      3u
#define  EX_BUTTON_INPUT_TASK_STK_SIZE  512u
#define  EX_SLIDER_INPUT_TASK_PRIO      2u
#define  EX_SLIDER_INPUT_TASK_STK_SIZE  512u
#define  EX_LED_OUTPUT_TASK_PRIO       	1u
#define  EX_LED_OUTPUT_TASK_STK_SIZE    512u
#define	 EX_BUTTON_INPUT_TASK_DELAY		50u
#define	 EX_SLIDER_INPUT_TASK_DELAY		100u
#define  EX_IDLE_TASK_STK_SIZE			64u
#define  EX_IDLE_TASK_PRIO				22u

//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************
